<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home_model extends CI_Model { 
    function get_table($tbl) {
        return $this->db->get($tbl)->result();
    }

    function insert_table($tbl, $data) {
        $this->db->insert($tbl, $data);
        return $this->db->insert_id();
    }

    function get_where_row($tbl, $where) {
        return $this->db->where($where)->get($tbl)->first_row();
    }

    function update_where_data($tbl, $data, $where) {
        return $this->db->update($tbl, $data, $where);
    }

    function delete_where_ar($tbl, $where) {
        $this->db->where($where);
        $this->db->delete($tbl);
    }
}