<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Product Page</title>
</head>
<body>
	<h4>Product Page</h4>
	<hr />

	<!-- CSS only -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

	<!-- jQuery CDN -->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<!-- JavaScript Bundle with Popper -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

	<!-- datatable CSS -->
	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
	<!-- datatable JS -->
	<script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>

	<div class="container">
		<?php
	    if ($this->session->flashdata('product_message')) {
	    	?>
	    	<div class='alert alert-success'>
	    		<strong>Success!</strong>
	    		<?php echo $this->session->flashdata('product_message'); ?>
	    	</div>	
	    	<?php 
	    }
	    ?>


		<!-- Button trigger modal -->
		<button type="button" class="btn btn-primary mb-2 btn_add_product" data-bs-toggle="modal" data-bs-target="#exampleModal" style="float: right;">
		  Add Product
		</button>

		<table id="myTable" class="display table table-bordered" style="width:100%">
	        <thead>
	            <tr>
	                <th>Sr. No.</th>
	                <th>Product Name</th>
	                <th>Product Price</th>
	                <th>Product Desc</th>
	                <th>Product Image</th> 
	                <th>Action</th>
	            </tr>
	        </thead>
	        <tbody>
	            <?php 
	            	$i = 1;
	            	if (!empty($product_data)) {
	            		foreach ($product_data as $value) {
	            			?>
	            			<tr>
	            				<td><?php echo $i; ?></td>
	            				<td><?php echo $value->product_name; ?></td>
	            				<td><?php echo $value->product_price; ?></td>
	            				<td><?php echo $value->product_desc; ?></td> 
	            				<td>
	            					<?php
		            					if ($value->product_image != '') {
		            						$img_arr = json_decode($value->product_image);
		            						// print_r($img_arr );

		            						foreach ($img_arr as $val) {
		            							$img_url = base_url()."uploads/".$val;
		            							?> 
		            								<img src="<?php echo $img_url; ?>" class="img-thumbnail" style="height: 20%; width: 20%;" />
		            							<?php
		            						}
		            					} 
	            					?>   
	            				</td>
	            				<td>
	            					<a href="javascript:void(0);" class="update" data-bs-toggle="modal" data-bs-target="#editModal" data-product_id='<?php echo $value->id; ?>'>Edit</a>
	            					<a href="javascript:void(0);" class="delete" data-product_id='<?php echo $value->id; ?>'>Delete</a>
	            				</td>
	            			</tr>  
	            			<?php
	            			$i++;
	            		}
	            	}
	            ?>
	        </tbody>
	        <tfoot>
	            <tr>
	                <th>Sr. No.</th>
	                <th>Product Name</th>
	                <th>Product Price</th>
	                <th>Product Desc</th>
	                <th>Product Image</th> 
	                <th>Action</th>
	            </tr>
	        </tfoot>
	    </table>	
	</div>

	

    
    <!-- Modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Add Product</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <form method="post" id="frm_add_product" name="frm_add_product" enctype="multipart/form-data" action="<?php echo base_url('home/add_product'); ?>">
		      <div class="modal-body">
		        
		        <div class="mb-3">
				  <label for="product_name" class="form-label">Product Name</label>
				  <input type="text" class="form-control" id="product_name" name="product_name" placeholder="Product Name">
				</div>

				<div class="mb-3">
				  <label for="product_price" class="form-label">Product Price</label>
				  <input type="text" class="form-control" id="product_price" name="product_price" placeholder="Product Name">
				</div>

				<div class="mb-3">
				  <label for="product_desc" class="form-label">Product Description</label>
				  <input type="text" class="form-control" id="product_desc" name="product_desc" placeholder="Product Description">
				</div>

				<div class="mb-3">
				  <label for="product_image" class="form-label">Product Image</label>
				  <input class="form-control" type="file" id="product_image" name="product_image[]" multiple />
				</div>

		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
		        <button type="submit" class="btn btn-primary">Save</button>
		      </div>
	      </form>
	    </div>
	  </div>
	</div>


	<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Edit Product</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <form method="post" id="frm_edit_product" name="frm_edit_product" enctype="multipart/form-data" action="<?php echo base_url('home/edit_product'); ?>">
		      <div class="modal-body">
		        
			        <div class="mb-3">
					  <label for="edtproduct_name" class="form-label">Product Name</label>
					  <input type="text" class="form-control" id="edtproduct_name" name="product_name" placeholder="Product Name" value="">
					</div>

					<div class="mb-3">
					  <label for="edtproduct_price" class="form-label">Product Price</label>
					  <input type="text" class="form-control" id="edtproduct_price" name="product_price" placeholder="Product Name">
					</div>

					<div class="mb-3">
					  <label for="edtproduct_desc" class="form-label">Product Description</label>
					  <input type="text" class="form-control" id="edtproduct_desc" name="product_desc" placeholder="Product Description">
					</div>

					<div class="mb-3">
					  <label for="edtproduct_image" class="form-label">Product Image</label>
					  <input class="form-control" type="file" id="edtproduct_image" name="product_image[]" multiple />
					</div> 

					<input type="hidden" name="hidden_product_image" id="hidden_product_image">

					<div class="disp_product_img"></div>

		      </div>  
		      <div class="modal-footer">
		        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
		        <button type="submit" class="btn btn-primary">Edit</button>
		      </div>
	      </form>
	    </div>
	  </div>
	</div>


	<script type="text/javascript">
	$(document).ready( function () {
		$('#myTable').DataTable();
   
		$("#frm_add_product").submit(function(e) {
		    e.preventDefault(); // prevent actual form submit
		    var form = $(this);
		    var url = form.attr('action'); //get submit url [replace url here if desired]
		    $.ajax({
		         type: "POST", 
		         url: url, 
		         data: new FormData(this),
		         processData:false,
	             contentType:false,
	             cache:false,
	             async:false,
		         success: function(data){
		             console.log(data);
		             location.reload();
		         }
		    });
		});

		$(document).on('click', '.update', function () {
			var product_id = $(this).data('product_id'); 
			var geturl = '<?php echo base_url('home/get_product/'); ?>'+ product_id; 
			$('#frm_edit_product').attr('action', '<?php echo base_url('home/edit_product/'); ?>'+ product_id);
			$.ajax({
		         type: "POST", 
		         url: geturl, 
		         dataType: 'json',
		         success: function(data){ 
		             $('#edtproduct_name').val(data.product_name);
		             $('#edtproduct_price').val(data.product_price);
		             $('#edtproduct_desc').val(data.product_desc);
		             $('#hidden_product_image').val(data.product_image);  

		             var json_img = JSON.parse(data.product_image); 
		             image_html = '';
		             $.each(json_img , function(index, val) {  
					  	image_html += "<img src=<?php echo base_url(); ?>uploads/" + val + " class='img-thumbnail mb-2' style='height: 20%; width: 20%;' />";
				     });
		             $('.disp_product_img').html(image_html);
		         }
		    });  
		}); 


		$("#frm_edit_product").submit(function(e) {
		    e.preventDefault(); // prevent actual form submit
		    var form = $(this);
		    var url = form.attr('action'); //get submit url [replace url here if desired]
		    $.ajax({
		         type: "POST", 
		         url: url, 
		         data: new FormData(this),
		         processData:false,
	             contentType:false,
	             cache:false,
	             async:false,
		         success: function(data){
		             location.reload();
		         }
		    });
		});


		$(document).on('click', '.delete', function () { 
            var product_id = $(this).data('product_id'); 
            var check = confirm("Are you sure you want to delete this row?");
            if (check == true) {
                $.ajax({
                    url: '<?php echo base_url('home/delete_product'); ?>',
                    type: 'POST',
                    data: {"product_id": product_id},
                    success: function (data) {
                        location.reload();
                    },
                    error: function (data) {
                        alert(data);
                    }
                });
            }
        });

        $(function() {
	    	$('.alert').delay(2000).show().fadeOut('slow');
		});
	});
	</script>

</body>
</html>