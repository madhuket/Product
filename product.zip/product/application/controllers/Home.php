<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	function __construct() {
        parent::__construct();
        $this->load->model('Home_model', 'home');
    }

	public function index()
	{
		$data['product_data'] = $this->home->get_table('product');
		$this->load->view('product', $data);
	}  

	public function add_product() {
		if (isset($_POST)) {
			$ins_data['product_name'] = $_POST['product_name'];
			$ins_data['product_price'] = $_POST['product_price'];
			$ins_data['product_desc'] = $_POST['product_desc'];
		} 

		if (isset($_FILES['product_image']['name'])) {
			$uploaded_file = array();
			$filesCount = count($_FILES['product_image']['name']);

			for($i = 0; $i < $filesCount; $i++){ 
				$_FILES['file']['name']     = $_FILES['product_image']['name'][$i]; 
                $_FILES['file']['type']     = $_FILES['product_image']['type'][$i]; 
                $_FILES['file']['tmp_name'] = $_FILES['product_image']['tmp_name'][$i]; 
                $_FILES['file']['error']     = $_FILES['product_image']['error'][$i]; 
                $_FILES['file']['size']     = $_FILES['product_image']['size'][$i]; 

                $config['upload_path'] = './uploads';  
				$config['allowed_types'] = 'jpg|jpeg|png'; 
				$this->upload->initialize($config);

				if($this->upload->do_upload('file')){ 
					$fileData = $this->upload->data(); 
					$uploaded_file[] = $fileData['file_name'];  
				} else {
					$error =  $this->upload->display_errors(); 
					echo json_encode(array('msg' => $error, 'success' => false));
				}
			} 

			if (!empty($uploaded_file)) {
				$ins_data['product_image'] = json_encode($uploaded_file);
			}   	  
		}	

		if (!empty($ins_data)) {
			$res = $this->home->insert_table('product', $ins_data);
			if ($res) {
				$arr = array('msg' => 'Data Inserted successfully', 'success' => true);

				$this->session->set_flashdata('product_message', 'Record Inserted Successfully');
			}
			echo json_encode($arr);
		} 
	}

	public function get_product($product_id)
	{ 
		$product_data = $this->home->get_where_row('product', array('id' => $product_id));
		echo json_encode($product_data);
		// echo json_encode($product_data);
	}

	public function edit_product($product_id) {
		if (isset($_POST)) {
			$up_data['product_name'] = $_POST['product_name'];
			$up_data['product_price'] = $_POST['product_price'];
			$up_data['product_desc'] = $_POST['product_desc'];
			$up_data['product_image'] = $_POST['hidden_product_image'];
		}   

		if (isset($_FILES['product_image']['name'])) {
			$uploaded_file = array();
			$filesCount = count($_FILES['product_image']['name']);

			for($i = 0; $i < $filesCount; $i++){ 
				$_FILES['file']['name']     = $_FILES['product_image']['name'][$i]; 
                $_FILES['file']['type']     = $_FILES['product_image']['type'][$i]; 
                $_FILES['file']['tmp_name'] = $_FILES['product_image']['tmp_name'][$i]; 
                $_FILES['file']['error']     = $_FILES['product_image']['error'][$i]; 
                $_FILES['file']['size']     = $_FILES['product_image']['size'][$i]; 

                $config['upload_path'] = './uploads';  
				$config['allowed_types'] = 'jpg|jpeg|png'; 
				$this->upload->initialize($config);

				if($this->upload->do_upload('file')){ 
					$fileData = $this->upload->data(); 
					$uploaded_file[] = $fileData['file_name'];  
				} else {
					$error =  $this->upload->display_errors(); 
					echo json_encode(array('msg' => $error, 'success' => false));
				}
			}

			if (!empty($uploaded_file)) {
				$up_data['product_image'] = json_encode($uploaded_file);
			}   	  
		}	

		if (!empty($up_data)) {
			$res = $this->home->update_where_data('product', $up_data, array('id' => $product_id));
			if ($res) {
				$arr = array('msg' => 'Data Updated successfully', 'success' => true);

				$this->session->set_flashdata('product_message', 'Record Updated Successfully');
			}  
			echo json_encode($arr);  
		}   
	}

	public function delete_product() {
        extract($_POST);
        $this->home->delete_where_ar('product', array('id' => $product_id));
        $this->session->set_flashdata('product_message', 'Record Deleted Successfully');
    }
}   
